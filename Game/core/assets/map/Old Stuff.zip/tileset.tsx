<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.0" name="tilepng" tilewidth="64" tileheight="64" spacing="2" margin="2" tilecount="504" columns="21">
 <image source="tilepng.png" trans="ff00ff" width="1388" height="1586"/>
</tileset>
