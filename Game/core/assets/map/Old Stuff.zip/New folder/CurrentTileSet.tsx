<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.0" name="Tileset1.3" tilewidth="32" tileheight="32" spacing="1" margin="1" tilecount="2016" columns="42">
 <image source="CurrentTileSet2.png" trans="ff00ff" width="1388" height="1586"/>
 <terraintypes>
  <terrain name="BarrenSand" tile="148"/>
  <terrain name="BarrenLow" tile="151"/>
  <terrain name="BarrenHigh" tile="154"/>
  <terrain name="FirtileSand" tile="274"/>
  <terrain name="FirtileLow" tile="277"/>
  <terrain name="FirtileHigh" tile="280"/>
  <terrain name="CurruptSand" tile="400"/>
  <terrain name="CurruptLow" tile="403"/>
  <terrain name="CurruptHigh" tile="406"/>
  <terrain name="CliffBase" tile="472"/>
  <terrain name="CliffLow" tile="475"/>
  <terrain name="CliffHigh" tile="478"/>
  <terrain name="CliffSnow" tile="481"/>
  <terrain name="Rocks" tile="220"/>
  <terrain name="FirtileBushes" tile="223"/>
  <terrain name="blank" tile="0"/>
 </terraintypes>
 <tile id="0" terrain=",,,15"/>
 <tile id="1" terrain=",,15,15"/>
 <tile id="2" terrain=",,15,"/>
 <tile id="9">
  <objectgroup draworder="index">
   <object id="1" x="2.63636" y="30.6364">
    <polygon points="0,0 27.8182,-14.1818 27.6364,-0.363636"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="10">
  <objectgroup draworder="index">
   <object id="1" x="0.909091" y="16.2727">
    <polygon points="0,0 30,-14.9091 30,14.0909 0.272727,14.3636"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="11">
  <objectgroup draworder="index">
   <object id="1" x="0.454545" y="0.727273" width="30.7273" height="30.3636"/>
  </objectgroup>
 </tile>
 <tile id="12">
  <objectgroup draworder="index">
   <object id="1" x="1.18182" y="1.54545">
    <polygon points="0,0 -0.0909091,28.9091 29.4545,29 29.5455,14.7273"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="13">
  <objectgroup draworder="index">
   <object id="1" x="1" y="17.4545">
    <polygon points="0,0 -0.0909091,13.3636 28.4545,13.7273"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="14">
  <objectgroup draworder="index">
   <object id="1" x="1.54545" y="30.8182">
    <polygon points="0,0 29.0909,-29 29,-0.0909091"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="15">
  <objectgroup draworder="index">
   <object id="1" x="3.45455" y="30.8182">
    <polygon points="0,0 27,-8.81818 27.0909,-0.454545"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="16">
  <objectgroup draworder="index">
   <object id="1" x="1.54545" y="20.6364">
    <polygon points="0,0 29.0909,-8.81818 29.0909,10.0909 -0.363636,10.1818"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="17">
  <objectgroup draworder="index">
   <object id="1" x="0.818182" y="10.6364">
    <polygon points="0,0 0,20.6364 29.8182,20.2727 30.1818,-9.90909"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="18">
  <objectgroup draworder="index">
   <object id="1" x="1.45455" y="1.63636">
    <polygon points="0,0 -0.636364,29.2727 29.3636,29.4545 29.3636,10.0909"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="19">
  <objectgroup draworder="index">
   <object id="1" x="1.36364" y="12.1818">
    <polygon points="0,0 -0.272727,18.5455 29.6364,18.4545 29.3636,8.90909"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="20">
  <objectgroup draworder="index">
   <object id="1" x="1.27273" y="22">
    <polygon points="0,0 -0.181818,9 28.0909,9.27273"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="21" terrain=",15,,15"/>
 <tile id="22" terrain="15,15,15,15"/>
 <tile id="23" terrain="15,,15,"/>
 <tile id="42" terrain=",15,,"/>
 <tile id="43" terrain="15,15,,"/>
 <tile id="44" terrain="15,,,"/>
 <tile id="63" terrain="15,15,15,"/>
 <tile id="64" terrain="15,15,,"/>
 <tile id="65" terrain="15,15,,15"/>
 <tile id="72">
  <objectgroup draworder="index">
   <object id="1" x="3.09091" y="31.2727">
    <polygon points="0,0 27.8182,-14.1818 27.6364,-0.363636"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="73">
  <objectgroup draworder="index">
   <object id="1" x="0.727273" y="16.4545">
    <polygon points="0,0 30,-14.9091 30,14.0909 0.272727,14.3636"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="84" terrain="15,,15,"/>
 <tile id="85" terrain="15,15,15,15"/>
 <tile id="86" terrain=",15,,15"/>
 <tile id="105" terrain="15,,15,15"/>
 <tile id="106" terrain=",,15,15"/>
 <tile id="107" terrain=",15,15,15"/>
 <tile id="126" terrain=",,,0">
  <objectgroup draworder="index">
   <object id="3" x="17.8182" y="30.8182">
    <polygon points="0,0 12.9091,-13.1818 12.9091,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="127" terrain=",,0,0">
  <objectgroup draworder="index">
   <object id="1" x="0.636364" y="16.5455" width="30.6364" height="14.2727"/>
  </objectgroup>
 </tile>
 <tile id="128" terrain=",,0,">
  <objectgroup draworder="index">
   <object id="1" x="14.0909" y="17.9091" rotation="180">
    <polygon points="0,-13.1818 12.9091,0 12.9091,-13.1818"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="129" terrain=",,,1"/>
 <tile id="130" terrain=",,1,1"/>
 <tile id="131" terrain=",,1,"/>
 <tile id="132" terrain=",,,2"/>
 <tile id="133" terrain=",,2,2"/>
 <tile id="134" terrain=",,2,"/>
 <tile id="135">
  <objectgroup draworder="index">
   <object id="1" x="2.81818" y="31.1818">
    <polygon points="0,0 27.8182,-14.1818 27.6364,-0.363636"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="136">
  <objectgroup draworder="index">
   <object id="1" x="0.818182" y="16.4545">
    <polygon points="0,0 30,-14.9091 30,14.0909 0.272727,14.3636"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="137">
  <objectgroup draworder="index">
   <object id="1" x="0.63635" y="0.545473" width="30.7273" height="30.3636"/>
  </objectgroup>
 </tile>
 <tile id="138">
  <objectgroup draworder="index">
   <object id="1" x="1.27273" y="1.72727">
    <polygon points="0,0 -0.0909091,28.9091 29.4545,29 29.5455,14.7273"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="139">
  <objectgroup draworder="index">
   <object id="1" x="1.45455" y="17.1818">
    <polygon points="0,0 -0.0909091,13.3636 28.4545,13.7273"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="140">
  <objectgroup draworder="index">
   <object id="1" x="1.54545" y="30.6364">
    <polygon points="0,0 29.0909,-29 29,-0.0909091"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="141">
  <objectgroup draworder="index">
   <object id="1" x="3.72727" y="31">
    <polygon points="0,0 27,-8.81818 27.0909,-0.454545"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="142">
  <objectgroup draworder="index">
   <object id="1" x="1.54545" y="21">
    <polygon points="0,0 29.0909,-8.81818 29.0909,10.0909 -0.363636,10.1818"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="143">
  <objectgroup draworder="index">
   <object id="1" x="0.636364" y="10.5455">
    <polygon points="0,0 0,20.6364 29.8182,20.2727 30.1818,-9.90909"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="144">
  <objectgroup draworder="index">
   <object id="1" x="1.54545" y="1.72727">
    <polygon points="0,0 -0.636364,29.2727 29.3636,29.4545 29.3636,10.0909"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="145">
  <objectgroup draworder="index">
   <object id="1" x="1.09091" y="12.0909">
    <polygon points="0,0 -0.272727,18.5455 29.6364,18.4545 29.3636,8.90909"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="146">
  <objectgroup draworder="index">
   <object id="1" x="1.18182" y="22.0909">
    <polygon points="0,0 -0.181818,9 28.0909,9.27273"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="147" terrain=",0,,0">
  <objectgroup draworder="index">
   <object id="1" x="16.5909" y="0.727273" width="14.6364" height="30"/>
  </objectgroup>
 </tile>
 <tile id="148" terrain="0,0,0,0"/>
 <tile id="149" terrain="0,,0,">
  <objectgroup draworder="index">
   <object id="1" x="0.545455" y="0.727273" width="14.6364" height="30"/>
  </objectgroup>
 </tile>
 <tile id="150" terrain=",1,,1"/>
 <tile id="151" terrain="1,1,1,1"/>
 <tile id="152" terrain="1,,1,"/>
 <tile id="153" terrain=",2,,2"/>
 <tile id="154" terrain="2,2,2,2"/>
 <tile id="155" terrain="2,,2,"/>
 <tile id="168" terrain=",0,,">
  <objectgroup draworder="index">
   <object id="1" x="18.1818" y="14.1818" rotation="360">
    <polygon points="0,-13.1818 12.9091,0 12.9091,-13.1818"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="169" terrain="0,0,,">
  <objectgroup draworder="index">
   <object id="1" x="0.590891" y="0.772741" width="30.6364" height="14.2727"/>
  </objectgroup>
 </tile>
 <tile id="170" terrain="0,,,">
  <objectgroup draworder="index">
   <object id="1" x="14" y="1.18182" rotation="-180">
    <polygon points="0,0 12.9091,-13.1818 12.9091,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="171" terrain=",1,,"/>
 <tile id="172" terrain="1,1,,"/>
 <tile id="173" terrain="1,,,"/>
 <tile id="174" terrain=",2,,"/>
 <tile id="175" terrain="2,2,,"/>
 <tile id="176" terrain="2,,,"/>
 <tile id="189" terrain="0,0,0,">
  <objectgroup draworder="index">
   <object id="1" x="1.18182" y="1">
    <polygon points="0,0 29.5455,-0.181818 29.5455,14.2727 14.0909,29.6364 -0.181818,29.3636"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="190" terrain="0,0,,">
  <objectgroup draworder="index">
   <object id="1" x="0.863618" y="1.22729" width="30.6364" height="14.2727"/>
  </objectgroup>
 </tile>
 <tile id="191" terrain="0,0,,0">
  <objectgroup draworder="index">
   <object id="1" x="30.8182" y="30.7273" rotation="180">
    <polygon points="0,29.4546 29.5455,29.6364 29.5455,15.1819 14.0909,-0.181818 -0.181818,0.090982"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="192" terrain="1,1,1,"/>
 <tile id="193" terrain="1,1,,"/>
 <tile id="194" terrain="1,1,,1"/>
 <tile id="195" terrain="2,2,2,"/>
 <tile id="196" terrain="2,2,,"/>
 <tile id="197" terrain="2,2,,2"/>
 <tile id="198" terrain="13,13,13,13">
  <objectgroup draworder="index">
   <object id="1" x="2.27273" y="30.9091">
    <polygon points="0,0 27.8182,-14.1818 27.6364,-0.363636"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="199" terrain="13,13,13,13">
  <objectgroup draworder="index">
   <object id="1" x="1.36364" y="16.5455">
    <polygon points="0,0 30,-14.9091 30,14.0909 0.272727,14.3636"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="200" terrain="13,13,13,13">
  <objectgroup draworder="index">
   <object id="1" x="0.818168" y="0.8182" width="30.7273" height="30.3636"/>
  </objectgroup>
 </tile>
 <tile id="201" terrain="14,14,14,14">
  <objectgroup draworder="index">
   <object id="1" x="1.36364" y="2.36364">
    <polygon points="0,0 -0.0909091,28.9091 29.4545,29 29.5455,14.7273"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="202" terrain="14,14,14,14">
  <objectgroup draworder="index">
   <object id="1" x="1.81818" y="17.4545">
    <polygon points="0,0 -0.0909091,13.3636 28.4545,13.7273"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="203" terrain="14,14,14,14">
  <objectgroup draworder="index">
   <object id="1" x="1.81818" y="30.8182">
    <polygon points="0,0 29.0909,-29 29,-0.0909091"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="204">
  <objectgroup draworder="index">
   <object id="1" x="3.63636" y="31.0909">
    <polygon points="0,0 27,-8.81818 27.0909,-0.454545"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="205">
  <objectgroup draworder="index">
   <object id="1" x="1.90909" y="20.4545">
    <polygon points="0,0 29.0909,-8.81818 29.0909,10.0909 -0.363636,10.1818"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="206">
  <objectgroup draworder="index">
   <object id="1" x="0.818182" y="10.9091">
    <polygon points="0,0 0,20.6364 29.8182,20.2727 30.1818,-9.90909"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="207">
  <objectgroup draworder="index">
   <object id="1" x="1.54545" y="1.54545">
    <polygon points="0,0 -0.636364,29.2727 29.3636,29.4545 29.3636,10.0909"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="208">
  <objectgroup draworder="index">
   <object id="1" x="1.36364" y="12.1818">
    <polygon points="0,0 -0.272727,18.5455 29.6364,18.4545 29.3636,8.90909"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="209">
  <objectgroup draworder="index">
   <object id="1" x="1.72727" y="22.0909">
    <polygon points="0,0 -0.181818,9 28.0909,9.27273"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="210" terrain="0,,0,">
  <objectgroup draworder="index">
   <object id="1" x="0.863618" y="1" width="14.6364" height="30"/>
  </objectgroup>
 </tile>
 <tile id="212" terrain=",0,,0">
  <objectgroup draworder="index">
   <object id="1" x="16.7727" y="1.09091" width="14.6364" height="30"/>
  </objectgroup>
 </tile>
 <tile id="213" terrain="1,,1,"/>
 <tile id="215" terrain=",1,,1"/>
 <tile id="216" terrain="2,,2,"/>
 <tile id="218" terrain=",2,,2"/>
 <tile id="219" terrain="13,13,13,13"/>
 <tile id="220" terrain="13,13,13,13"/>
 <tile id="221" terrain="13,0,13,13"/>
 <tile id="222" terrain="14,14,14,14"/>
 <tile id="223" terrain="14,14,14,14"/>
 <tile id="224" terrain="14,14,14,14"/>
 <tile id="231" terrain="0,,0,0">
  <objectgroup draworder="index">
   <object id="1" x="1.09091" y="1.36364">
    <polygon points="0,29.4546 29.5455,29.6364 29.5455,15.1819 14.0909,-0.181818 -0.181818,0.090982"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="232" terrain=",,0,0">
  <objectgroup draworder="index">
   <object id="1" x="0.772709" y="16.9546" width="30.6364" height="14.2727"/>
  </objectgroup>
 </tile>
 <tile id="233" terrain=",0,0,0">
  <objectgroup draworder="index">
   <object id="1" x="30.5455" y="30.5455" rotation="-180">
    <polygon points="0,0 29.5455,-0.181818 29.5455,14.2727 14.0909,29.6364 -0.181818,29.3636"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="234" terrain="1,,1,1"/>
 <tile id="235" terrain=",,1,1"/>
 <tile id="236" terrain=",1,1,1"/>
 <tile id="237" terrain="2,,2,2"/>
 <tile id="238" terrain=",,2,2"/>
 <tile id="239" terrain=",2,2,2"/>
 <tile id="240" terrain="13,13,13,13"/>
 <tile id="241" terrain="13,13,13,13"/>
 <tile id="242" terrain="13,13,13,13"/>
 <tile id="243" terrain="14,14,14,14"/>
 <tile id="244" terrain="14,14,14,14"/>
 <tile id="245" terrain="14,14,14,14"/>
 <tile id="252" terrain=",,,3">
  <objectgroup draworder="index">
   <object id="1" x="17.7273" y="30.8182">
    <polygon points="0,0 12.9091,-13.1818 12.9091,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="253" terrain=",,3,3">
  <objectgroup draworder="index">
   <object id="1" x="0.499982" y="17.0455" width="30.6364" height="14.2727"/>
  </objectgroup>
 </tile>
 <tile id="254" terrain=",,3,">
  <objectgroup draworder="index">
   <object id="1" x="14.2727" y="18" rotation="180">
    <polygon points="0,-13.1818 12.9091,0 12.9091,-13.1818"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="255" terrain=",,,4"/>
 <tile id="256" terrain=",,4,4"/>
 <tile id="257" terrain=",,4,"/>
 <tile id="258" terrain=",,,5"/>
 <tile id="259" terrain=",,5,5"/>
 <tile id="260" terrain=",,5,"/>
 <tile id="273" terrain=",3,,3">
  <objectgroup draworder="index">
   <object id="1" x="16.5909" y="1" width="14.6364" height="30"/>
  </objectgroup>
 </tile>
 <tile id="274" terrain="3,3,3,3"/>
 <tile id="275" terrain="3,,3,">
  <objectgroup draworder="index">
   <object id="1" x="0.6818" y="0.636364" width="14.6364" height="30"/>
  </objectgroup>
 </tile>
 <tile id="276" terrain=",4,,4"/>
 <tile id="277" terrain="4,4,4,4"/>
 <tile id="278" terrain="4,,4,"/>
 <tile id="279" terrain=",5,,5"/>
 <tile id="280" terrain="5,5,5,5"/>
 <tile id="281" terrain="5,,5,"/>
 <tile id="294" terrain=",3,,">
  <objectgroup draworder="index">
   <object id="1" x="18.3636" y="14" rotation="360">
    <polygon points="0,-13.1818 12.9091,0 12.9091,-13.1818"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="295" terrain="3,3,,">
  <objectgroup draworder="index">
   <object id="1" x="0.590891" y="0.954559" width="30.6364" height="14.2727"/>
  </objectgroup>
 </tile>
 <tile id="296" terrain="3,,,">
  <objectgroup draworder="index">
   <object id="1" x="14" y="0.909091" rotation="-180">
    <polygon points="0,0 12.9091,-13.1818 12.9091,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="297" terrain=",4,,"/>
 <tile id="298" terrain="4,4,,"/>
 <tile id="299" terrain="4,,,"/>
 <tile id="300" terrain=",5,,"/>
 <tile id="301" terrain="5,5,,"/>
 <tile id="302" terrain="5,,,"/>
 <tile id="315" terrain="3,3,3,">
  <objectgroup draworder="index">
   <object id="1" x="1.90909" y="1">
    <polygon points="0,0 29.5455,-0.181818 29.5455,14.2727 14.0909,29.6364 -0.181818,29.3636"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="316" terrain="3,3,,">
  <objectgroup draworder="index">
   <object id="1" x="0.6818" y="0.954559" width="30.6364" height="14.2727"/>
  </objectgroup>
 </tile>
 <tile id="317" terrain="3,3,,3">
  <objectgroup draworder="index">
   <object id="1" x="31.0909" y="30.5455" rotation="180">
    <polygon points="0,29.4546 29.5455,29.6364 29.5455,15.1819 14.0909,-0.181818 -0.181818,0.090982"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="318" terrain="4,4,4,"/>
 <tile id="319" terrain="4,4,,"/>
 <tile id="320" terrain="4,4,,4"/>
 <tile id="321" terrain="5,5,5,"/>
 <tile id="322" terrain="5,5,,"/>
 <tile id="323" terrain="5,5,,5"/>
 <tile id="336" terrain="3,,3,">
  <objectgroup draworder="index">
   <object id="1" x="0.590891" y="1.18182" width="14.6364" height="30"/>
  </objectgroup>
 </tile>
 <tile id="338" terrain=",3,,3">
  <objectgroup draworder="index">
   <object id="1" x="16.5909" y="0.909091" width="14.6364" height="30"/>
  </objectgroup>
 </tile>
 <tile id="339" terrain="4,,4,"/>
 <tile id="341" terrain=",4,,4"/>
 <tile id="342" terrain="5,,5,"/>
 <tile id="344" terrain=",5,,5"/>
 <tile id="357" terrain="3,,3,3">
  <objectgroup draworder="index">
   <object id="1" x="1.45455" y="1.27273">
    <polygon points="0,29.4546 29.5455,29.6364 29.5455,15.1819 14.0909,-0.181818 -0.181818,0.090982"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="358" terrain=",,3,3">
  <objectgroup draworder="index">
   <object id="1" x="0.590891" y="16.7727" width="30.6364" height="14.2727"/>
  </objectgroup>
 </tile>
 <tile id="359" terrain=",3,3,3">
  <objectgroup draworder="index">
   <object id="1" x="30.5455" y="31" rotation="-180">
    <polygon points="0,0 29.5455,-0.181818 29.5455,14.2727 14.0909,29.6364 -0.181818,29.3636"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="360" terrain="4,,4,4"/>
 <tile id="361" terrain=",,4,4"/>
 <tile id="362" terrain=",4,4,4"/>
 <tile id="363" terrain="5,,5,5"/>
 <tile id="364" terrain=",,5,5"/>
 <tile id="365" terrain=",5,5,5"/>
 <tile id="366" terrain="9,9,9,9"/>
 <tile id="367" terrain="9,9,9,9"/>
 <tile id="368" terrain="9,9,9,9"/>
 <tile id="369" terrain="10,10,10,10"/>
 <tile id="370" terrain="10,10,10,10"/>
 <tile id="371" terrain="10,10,10,10"/>
 <tile id="372" terrain="11,11,11,11"/>
 <tile id="373" terrain="11,11,11,11"/>
 <tile id="374" terrain="11,11,11,11"/>
 <tile id="375" terrain="12,12,12,12"/>
 <tile id="376" terrain="12,12,12,12"/>
 <tile id="377" terrain="12,12,12,12"/>
 <tile id="378" terrain=",,,6">
  <objectgroup draworder="index">
   <object id="1" x="17.7273" y="31.0909">
    <polygon points="0,0 12.9091,-13.1818 12.9091,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="379" terrain=",,6,6">
  <objectgroup draworder="index">
   <object id="1" x="0.863618" y="16.8636" width="30.6364" height="14.2727"/>
  </objectgroup>
 </tile>
 <tile id="380" terrain=",,6,">
  <objectgroup draworder="index">
   <object id="1" x="13.8182" y="18.1818" rotation="180">
    <polygon points="0,-13.1818 12.9091,0 12.9091,-13.1818"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="381" terrain=",,,7"/>
 <tile id="382" terrain=",,7,7"/>
 <tile id="383" terrain=",,7,"/>
 <tile id="384" terrain=",,,8"/>
 <tile id="385" terrain=",,8,8"/>
 <tile id="386" terrain=",,8,"/>
 <tile id="387" terrain=",,,9">
  <objectgroup draworder="index">
   <object id="1" x="17.7273" y="31.0909">
    <polygon points="0,0 12.9091,-13.1818 12.9091,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="388" terrain=",,9,9">
  <objectgroup draworder="index">
   <object id="1" x="0.6818" y="16.6818" width="30.6364" height="14.2727"/>
  </objectgroup>
 </tile>
 <tile id="389" terrain=",,9,">
  <objectgroup draworder="index">
   <object id="1" x="13.6364" y="17.6364" rotation="180">
    <polygon points="0,-13.1818 12.9091,0 12.9091,-13.1818"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="390" terrain=",,,10"/>
 <tile id="391" terrain=",,10,10"/>
 <tile id="392" terrain=",,10,"/>
 <tile id="393" terrain=",,,11"/>
 <tile id="394" terrain=",,11,11"/>
 <tile id="395" terrain=",,11,"/>
 <tile id="396" terrain=",,,12"/>
 <tile id="397" terrain=",,12,12"/>
 <tile id="398" terrain=",,12,"/>
 <tile id="399" terrain=",6,,6">
  <objectgroup draworder="index">
   <object id="1" x="16.5" y="1.18182" width="14.6364" height="30"/>
  </objectgroup>
 </tile>
 <tile id="400" terrain="6,6,6,6"/>
 <tile id="401" terrain="6,,6,">
  <objectgroup draworder="index">
   <object id="1" x="0.863618" y="1" width="14.6364" height="30"/>
  </objectgroup>
 </tile>
 <tile id="402" terrain=",7,,7"/>
 <tile id="403" terrain="7,7,7,7"/>
 <tile id="404" terrain="7,,7,"/>
 <tile id="405" terrain=",8,,8"/>
 <tile id="406" terrain="8,8,8,8"/>
 <tile id="407" terrain="8,,8,"/>
 <tile id="408" terrain=",9,,9">
  <objectgroup draworder="index">
   <object id="1" x="17.0454" y="1" width="14.6364" height="30"/>
  </objectgroup>
 </tile>
 <tile id="410" terrain="9,,9,">
  <objectgroup draworder="index">
   <object id="1" x="0.772709" y="1.45455" width="14.6364" height="30"/>
  </objectgroup>
 </tile>
 <tile id="411" terrain=",10,,10"/>
 <tile id="413" terrain="10,,10,"/>
 <tile id="414" terrain=",11,,11"/>
 <tile id="416" terrain="11,,11,"/>
 <tile id="417" terrain=",12,,12"/>
 <tile id="419" terrain="12,,12,"/>
 <tile id="420" terrain=",6,,">
  <objectgroup draworder="index">
   <object id="1" x="18.2727" y="14.1818" rotation="360">
    <polygon points="0,-13.1818 12.9091,0 12.9091,-13.1818"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="421" terrain="6,6,,">
  <objectgroup draworder="index">
   <object id="1" x="0.590891" y="1.13638" width="30.6364" height="14.2727"/>
  </objectgroup>
 </tile>
 <tile id="422" terrain="6,,,">
  <objectgroup draworder="index">
   <object id="1" x="13.7273" y="1.09091" rotation="-180">
    <polygon points="0,0 12.9091,-13.1818 12.9091,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="423" terrain=",7,,"/>
 <tile id="424" terrain="7,7,,"/>
 <tile id="425" terrain="7,,,"/>
 <tile id="426" terrain=",8,,"/>
 <tile id="427" terrain="8,8,,"/>
 <tile id="428" terrain="8,,,"/>
 <tile id="429" terrain=",9,,">
  <objectgroup draworder="index">
   <object id="1" x="18.3636" y="14.2727" rotation="360">
    <polygon points="0,-13.1818 12.9091,0 12.9091,-13.1818"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="430" terrain="9,9,,">
  <objectgroup draworder="index">
   <object id="1" x="0.6818" y="0.954559" width="30.6364" height="14.2727"/>
  </objectgroup>
 </tile>
 <tile id="431" terrain="9,,,">
  <objectgroup draworder="index">
   <object id="1" x="13.8182" y="0.909091" rotation="-180">
    <polygon points="0,0 12.9091,-13.1818 12.9091,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="432" terrain=",10,,"/>
 <tile id="433" terrain="10,10,,"/>
 <tile id="434" terrain="10,,,"/>
 <tile id="435" terrain=",11,,"/>
 <tile id="436" terrain="11,11,,"/>
 <tile id="437" terrain="11,,,"/>
 <tile id="438" terrain=",12,,"/>
 <tile id="439" terrain="12,12,,"/>
 <tile id="440" terrain="12,,,"/>
 <tile id="441" terrain="6,6,6,">
  <objectgroup draworder="index">
   <object id="1" x="1" y="1.27273">
    <polygon points="0,0 29.5455,-0.181818 29.5455,14.2727 14.0909,29.6364 -0.181818,29.3636"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="442" terrain="6,6,,">
  <objectgroup draworder="index">
   <object id="1" x="0.590891" y="1.13638" width="30.6364" height="14.2727"/>
  </objectgroup>
 </tile>
 <tile id="443" terrain="6,6,,6">
  <objectgroup draworder="index">
   <object id="1" x="31" y="31.0909" rotation="180">
    <polygon points="0,29.4546 29.5455,29.6364 29.5455,15.1819 14.0909,-0.181818 -0.181818,0.090982"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="444" terrain="7,7,7,"/>
 <tile id="445" terrain="7,7,,"/>
 <tile id="446" terrain="7,7,,7"/>
 <tile id="447" terrain="8,8,8,"/>
 <tile id="448" terrain="8,8,,"/>
 <tile id="449" terrain="8,8,,8"/>
 <tile id="450" terrain="9,9,9,">
  <objectgroup draworder="index">
   <object id="1" x="1.27273" y="1.18182">
    <polygon points="0,0 29.5455,-0.181818 29.5455,14.2727 14.0909,29.6364 -0.181818,29.3636"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="451" terrain="9,9,,">
  <objectgroup draworder="index">
   <object id="1" x="0.954527" y="0.954559" width="30.6364" height="14.2727"/>
  </objectgroup>
 </tile>
 <tile id="452" terrain="9,9,,9">
  <objectgroup draworder="index">
   <object id="1" x="30.9091" y="30.7273" rotation="180">
    <polygon points="0,29.4546 29.5455,29.6364 29.5455,15.1819 14.0909,-0.181818 -0.181818,0.090982"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="453" terrain="10,10,10,"/>
 <tile id="454" terrain="10,10,,"/>
 <tile id="455" terrain="10,10,,10"/>
 <tile id="456" terrain="11,11,11,"/>
 <tile id="457" terrain="11,11,,"/>
 <tile id="458" terrain="11,11,,11"/>
 <tile id="459" terrain="12,12,12,"/>
 <tile id="460" terrain="12,12,,"/>
 <tile id="461" terrain="12,12,,12"/>
 <tile id="462" terrain="6,,6,">
  <objectgroup draworder="index">
   <object id="1" x="0.772709" y="1" width="14.6364" height="30"/>
  </objectgroup>
 </tile>
 <tile id="464" terrain=",6,,6">
  <objectgroup draworder="index">
   <object id="1" x="16.7727" y="0.909091" width="14.6364" height="30"/>
  </objectgroup>
 </tile>
 <tile id="465" terrain="7,,7,"/>
 <tile id="467" terrain=",7,,7"/>
 <tile id="468" terrain="8,,8,"/>
 <tile id="470" terrain=",8,,8"/>
 <tile id="471" terrain="9,,9,">
  <objectgroup draworder="index">
   <object id="1" x="0.590891" y="1.09091" width="14.6364" height="30"/>
  </objectgroup>
 </tile>
 <tile id="472" terrain="9,9,9,9"/>
 <tile id="473" terrain=",9,,9">
  <objectgroup draworder="index">
   <object id="1" x="16.5909" y="1.09091" width="14.6364" height="30"/>
  </objectgroup>
 </tile>
 <tile id="474" terrain="10,,10,"/>
 <tile id="475" terrain="10,10,10,10"/>
 <tile id="476" terrain=",10,,10"/>
 <tile id="477" terrain="11,,11,"/>
 <tile id="478" terrain="11,11,11,11"/>
 <tile id="479" terrain=",11,,11"/>
 <tile id="480" terrain="12,,12,"/>
 <tile id="481" terrain="12,12,12,12"/>
 <tile id="482" terrain=",12,,12"/>
 <tile id="483" terrain="6,,6,6">
  <objectgroup draworder="index">
   <object id="1" x="1.36364" y="1.09091">
    <polygon points="0,29.4546 29.5455,29.6364 29.5455,15.1819 14.0909,-0.181818 -0.181818,0.090982"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="484" terrain=",,6,6">
  <objectgroup draworder="index">
   <object id="1" x="0.499982" y="17.0455" width="30.6364" height="14.2727"/>
  </objectgroup>
 </tile>
 <tile id="485" terrain=",6,6,6">
  <objectgroup draworder="index">
   <object id="1" x="30.7273" y="31.0909" rotation="-180">
    <polygon points="0,0 29.5455,-0.181818 29.5455,14.2727 14.0909,29.6364 -0.181818,29.3636"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="486" terrain="7,,7,7"/>
 <tile id="487" terrain=",,7,7"/>
 <tile id="488" terrain=",7,7,7"/>
 <tile id="489" terrain="8,,8,8"/>
 <tile id="490" terrain=",,8,8"/>
 <tile id="491" terrain=",8,8,8"/>
 <tile id="492" terrain="9,,9,9">
  <objectgroup draworder="index">
   <object id="1" x="1.54545" y="1.54545">
    <polygon points="0,29.4546 29.5455,29.6364 29.5455,15.1819 14.0909,-0.181818 -0.181818,0.090982"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="493" terrain=",,9,9">
  <objectgroup draworder="index">
   <object id="1" x="0.863618" y="16.6818" width="30.6364" height="14.2727"/>
  </objectgroup>
 </tile>
 <tile id="494" terrain=",9,9,9">
  <objectgroup draworder="index">
   <object id="1" x="31.0909" y="30.6364" rotation="-180">
    <polygon points="0,0 29.5455,-0.181818 29.5455,14.2727 14.0909,29.6364 -0.181818,29.3636"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="495" terrain="10,,10,10"/>
 <tile id="496" terrain=",,10,10"/>
 <tile id="497" terrain=",10,10,10"/>
 <tile id="498" terrain="11,,11,11"/>
 <tile id="499" terrain=",,11,11"/>
 <tile id="500" terrain=",11,11,11"/>
 <tile id="501" terrain="12,,12,12"/>
 <tile id="502" terrain=",,12,12"/>
 <tile id="503" terrain=",12,12,12"/>
</tileset>
